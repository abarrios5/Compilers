import java.io.*;  
import java.nio.file.*;; 

public class txtReader {
	 public static String readFileAsString()throws Exception 
	  { 
	    String data = ""; 
	    data = new String(Files.readAllBytes(Paths.get("ABC.txt"))); 
	    return data; 
	  } 
	  
	  public static void main(String[] args) throws Exception 
	  { 
	    System.out.println(txtReader.readFileAsString()); 
	  } 
}
