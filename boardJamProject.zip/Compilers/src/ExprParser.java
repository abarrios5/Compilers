import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;			  ///////////////////////////////////					   	 ////////////////
//////////////////////////////////////////								    /////////////////////////
//THIS IS THE CODE FOR PHASE 2.2 OF Limp.///////////////////////////////////						//////////////////
/////////////////////////////////////////									/////////////////////////
										////////////////////////////////////						//////////////////
////////////////////////////////////////								   /////////////////////////									
//Antonio Barrios
//March 28
//Enter code to parse after enter input/
//EX of code it parses. while x do y endwhile 

public class ExprParser {
	static Scanner in = new Scanner(System.in); 
	static Scan getScanToke = new Scan();
	static String[] arr = new String[100];
	static Pattern p =Pattern.compile("if|then|else|endIf|while|do|endWhile|skip");
	static GCF nod = new GCF();
	static int count = 0;
	static String token;
	static int z = 0;
	static PTNode root;
	
	public static void main(String[] args) throws Throwable
	{
		System.out.println("Enter input: ");
		String input = in.nextLine();
		String[] line = input.split(" ");
		System.out.println("____________________________________");
		//We pass the tokens into an array here.
		for(String a : line) 
		{
			arraySaver(a);
		}
		
		//This Prints out the tokens that are passed into the code
		for(int i = 0; i < arr.length; i++)
		{
			if(arr[i] != null) {
				System.out.println("Tokens: " + arr[i]);
			}else {
				continue;
			} 
		}
		System.out.println("____________________________________");

		par();
		makeTree();
	}
	
	public static void makeTree() throws Throwable 
	{
		GCF.print2D(root);
	}
	
	public static void par() throws Throwable
	{
		getToken();
		command(); 
	}
	
	public static void arraySaver(String s) 
	{
		 arr[count++] = s;
	}
	
	public static void getToken() throws Throwable
	{
		if(arr[z] != null) {
			token = arr[z++];
			System.out.println("From getToken(): " + token);
		}
	}	
	
	public static void command() throws Throwable 
	{
		String result = statement();
		System.out.println("Final: " + result);	
	}
	
	public static String statement() throws Throwable 
	{
		String result = baseStatement();
		if(token.equals(";"))
		{
			match(";");
			result = token;
		}
		return result;
	}
	
	public static String baseStatement() throws Throwable 
	{
		String result = assignment();
		System.out.println("BaseStatement: " + token);
		if(token.equals("if")) 
		{
			match("if");
			result = ifStatement();
			System.out.println("BaseState/If: " + result);
		}else if(token.equals("while")) 
		{  
			//root.right = new PTNode("while");  
			match("while");
			result = whileStatement();
			System.out.println("BaseState/While: " + result);
		}
		System.out.println("BaseStatement outside: " + result);
		return result;
	}
	
	public static String assignment() throws Throwable 
	{
		String result =  token;
		Matcher m = p.matcher(result);
		if (m.find()) 
		{
			//System.out.println("assignment: " + result);
			result = token;
		}
			//match(token);
			System.out.println("Assignment: " + result);
			return result;
	}
	
	public static String ifStatement() throws Throwable 
	{	
		String result;
			result = assignment();
			System.out.println("From If/Statement 1: " + result);
			match(result);
			result = statement();
			//
			match("then");
			result = statement();
			System.out.println("From If/Statement 2: " + result);
			match(result);
			result = statement();
			//
			match("else");
			result = statement();
			System.out.println("From If/Statement 3: " + result);
			match(result);
			result = statement();
			//
			match("endif");
			result = assignment();
			return result;
	}
	
	public static String whileStatement() throws Throwable 
	{
		String result;
		result = assignment();
		System.out.println("From While/Statement 1: " + result);
		PTNode root = new PTNode(result); // Tree root
		match(result);
		result = statement();
		//
		match("do");
		result = statement();
		System.out.println("From While/Statement 2: " + result);
		root.left = new PTNode(result);
		match(result);
		result = statement();
		//
		match("else");
		result = assignment();
		root.right = new PTNode(result);
		return result;
	}
	
	public static void match(String c) throws Throwable 
	{	
		if(token.equals(c)) 
			getToken();
		else error();
	}
	
	public static void error() 
	{
		System.out.println("parse error");
	}
}
