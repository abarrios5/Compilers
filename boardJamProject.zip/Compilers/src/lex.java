import java.io.*; 

public class lex {
	
	public static void main(String[] args) throws InterruptedException,  
	                                              FileNotFoundException, IOException {
	
		FileReader reader = new FileReader("ABC.txt"); 
		BufferedReader bufferread = new BufferedReader(reader); 
		StreamTokenizer token = new StreamTokenizer(bufferread); 
		//lex type = new lex();
		//type.type(token);
		// Use of commentChar() method 
		token.commentChar('a'); 
		int t; 
		while ((t = token.nextToken()) != StreamTokenizer.TT_EOF) 
		{ 
			switch (t) { 
				case StreamTokenizer.TT_NUMBER: 
					System.out.println("Number : " + token.nval); 
					break;
				case StreamTokenizer.TT_WORD: 
					System.out.println("Word : " + token.sval); 
					break;
			}
		} 
		lex.runMan(token); 	
	}
	
	public static TokeType type(StreamTokenizer t) throws IOException {
		int z;
		while ((z = t.nextToken()) != StreamTokenizer.TT_EOF) {
			if(z == ' ') {
				return  TokeType.TT_WSPACE;
			}else if(z == '+') {
				return TokeType.TT_PLUS;
			}else if(z == '*') {
				return TokeType.TT_TIMES;
			}else if(z == '(') {
				return TokeType.TT_LPAREN;
			}else if(z == ')') {
				return TokeType.TT_RPAREN;
			}else if(z == '-') {
				return TokeType.TT_SUB;
			}else if(z == '\n') {
				return TokeType.TT_EOL;
			}else{
				return TokeType.TT_NUMBER;
			}
		}
		return TokeType.TT_EOL;
	}


public static void runMan(StreamTokenizer i) throws IOException {
	TokeType toke;
	
    do {
		toke = lex.type(i);
			switch (toke){
				case TT_WSPACE: System.out.println("TT_WSPACE: ' ' "); break;
				case TT_PLUS : System.out.println("TT_PLUS : +"); break;
				case TT_TIMES:  System.out.println("TT_TIMES : *"); break;
				case TT_LPAREN: System.out.println("TT_LPAREN : ("); break;		
				case TT_RPAREN: System.out.println("TT_RPAREN : )"); break;
				case TT_SUB: System.out.println("TT_SUB : -"); break; 
				case TT_NUMBER: System.out.println("NUMBER: "); break; 
				case TT_EOL: System.out.println("TT_EOL : " ); break;  
				default : System.out.println("ERROR WITH FIle"); break;
			}
	}while(toke != TokeType.TT_EOL );

}
}
        

