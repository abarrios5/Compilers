import java.util.NoSuchElementException;

public class ErrorHandle {
	
	static void endFile(TokeType i) {
		try {
			return;
		}
		catch(NoSuchElementException ex) {
			System.out.println("End of File");
		}
	}
}
