import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;

//this is the code for phase 1.2 of limp

public class Scan {
	static int token;
	static int[] arr = new int[100];
	static String[] arrC = new String[100];
	static String[] arrID = new String[100];
	static String[] arrK = new String[100];
	
	
	
	public static int count = 0;
	public static StringTokenizer st;
	static txtReader txt = new txtReader();
	static String ID;
	static int NUMBER;
	static String SYM[]= {"+", "-", "*", "\n", "(", ")", ":", "=", ";"};
	static String KEYWORD[] = {"if", "then", "else", "endIf", "while", 
								"do", "endWhile", "skip"};
	
	
	public static void getStringNum(String s) 
	{
		int num = 0;
		st = new StringTokenizer(s);
		while(st.hasMoreTokens()) {
			num = Integer.parseInt(st.nextToken());	
		}
		numericalArraySaver(num);
	}
	
	public static String KEYWORD(String a) throws Throwable 
	{
		Pattern p =Pattern.compile("if|then|else|endIf|while|do|endWhile|skip");
		Matcher m = p.matcher(a);
		while(m.find()){
			return m.group();
		}
		return null;
	}
			
	public static void numericalArraySaver(int num) 
	{
		 arr[count++] = num;
	}
	
	public static void charArraySaver(String c) 
	{
		arrC[count++] = c;
	}
	
	public static String IDArraySaver(String c) 
	{
		return arrID[count++] = c;
	}
	
	public static void keyArraySaver(String c) 
	{
		arrK[count++] = c;
	}
	
	public static void printKey() throws Throwable 
	{
		for(int i = 0; i < arrK.length; i++)
		{
			if(arrK[i] != null) {
				System.out.println("KEYWORD: " +KEYWORD(arrK[i]));
			}else {
				continue;
			} 
		}
	}
	
	public static void printChar() 
	{
		for(int i = 0; i < arrC.length; i++)
		{
			if(arrC[i] != null) {
				System.out.println("SYMBOL: " + arrC[i]);
			}else {
				continue;
			} 
		}
	}
	
	public static void printID() 
	{
		for(int i = 0; i < arrID.length; i++)
		{
			if(arrID[i] != null) {
				System.out.println("ID: " + arrID[i]);
			}else {
				continue;
			} 
		}
	}
	

	public static void printNum() 
	{
		for(int i = 0; i < arr.length; i++)
		{
			if(arr[i] != 0) {
				System.out.println("NUMBER: " + arr[i]);
			}else {
				continue;
			} 
		}
	}
			
	public static void runnerForOthers(String in) throws Throwable 
	{
			
		Scanner input = new Scanner(in);
		//System.out.println("Mathematical Expression");	
		String mathExpr = input.nextLine();
		String[] getNum = mathExpr.split("\\:=|\\+|\\-|\\*|\\/|\\(|\\)|if|then|else|endIf|while|do|endWhile|skip|[a-z]|[A-Z]|[a-z]|[A-Z]");
		String[] getChar = mathExpr.split("[0-9]+|if|then|else|endIf|while|do|endWhile|skip|[a-z]|[A-Z]|[a-z]|[A-Z]");
		String[] getKeyWord = mathExpr.split("\\+|\\-|\\*|\\/|\\(|\\)|[0-9]+");
		String[] getID = mathExpr.split("[0-9]+|if|then|else|endif|while|do|endwhile|skip|\\+|\\-|\\*|\\/|\\(|\\)");

		
		

		for(String a : getKeyWord) 
		{
			keyArraySaver(a);
		}
		
		
		for(String a : getChar) 
		{
			charArraySaver(a);
		}
		
		for(String a : getID) 
		{
			IDArraySaver(a);
		}
		
		for(String a : getNum) 	
		{
			getStringNum(a);
		}
		
		 printChar();
		 printNum();
		 printID();
		 printKey();
	}
	
	public static void main(String[] args) throws Throwable {
		Scanner in = new Scanner(System.in);
		String input = in.nextLine();
		runnerForOthers(input);
	}

}
