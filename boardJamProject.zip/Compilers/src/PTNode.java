

class PTNode 
{ 
	String data;  
	PTNode left, right;  
	      
	    /* Constructor that allocates a new node with the  
	    given data and null left and right pointers. */
    PTNode(String data) 
    {  
    	this.data = data;  
	    this.left = null;  
	    this.right = null;  
	}  
}

  




