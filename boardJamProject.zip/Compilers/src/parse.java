import java.util.*;
import java.util.regex.Pattern;
import java.lang.Object;
import java.lang.reflect.Array;

//This is the code for phase 2.1 of limp
public class parse {
static int token;
	
	public static int digit() throws Throwable 
	{
		int result = 0;
		if(Character.isDigit(token)) {
			result = token - 48;
			char c = (char) token;
			System.out.println("NUMBER: " + result);
			match(c);
		}else 
			error();
			return result;
	}

	public static void error() 
	{
		System.out.println("Parsing error");
	}

	public static void match(char c) throws Throwable 
	{
		if(token == c ) getToken();
		else error();
	}

	public static int number() throws Throwable
	{
		int result = digit();
		while (Character.isDigit(token) ) 
			result = 10 * result + digit();
			System.out.println("number: " + result);
			return result;
	}
	
	public static int factor() throws Throwable
	{
		int result; 
		if (token == '(') {
			match('(');
			result = expr();
			match(')');
		}else
			result = number();
			System.out.println("SYMBOL/fact: " + result);
			return result;
	}

	public static int term() throws Throwable 
	{
		int result = factor();
		if (token == '*') {
			System.out.println("SYMBOL: *");
			match('*');
			result *= term();
			System.out.println("term: "+ result);
		}
		return result;
	}

	public static int minus() throws Throwable 
	{
		int result = term();
		if (token == '-') {
			System.out.println("SYMBOL: -" );
			match('-');
			result -= minus();
			System.out.println("minus: " + result);
		}
		return result;
	}

	public static int expr() throws Throwable
	{
		int result = minus();
		if (token == '+') {
			System.out.println("SYMBOL: +" );
			match('+');
			result += expr();
			System.out.println("expr: " + result);
		}
		return result;
	}

	public static void command() throws Throwable {
		int result = expr();
		if (token == '\n') {
			System.out.println("The result is :" + result);
		}
		else error();
	}
	
	public final static int nextChar(Scanner scanner) 
	{
		scanner.useDelimiter("");
		int ret;
		ret = scanner.next().charAt(0);
		scanner.reset();
		return ret;
	}

	public static void getToken() throws Throwable 
	{
		Scanner in = new Scanner(System.in);
		token = nextChar(in);
			if (token == ' ' || token == '\t') getToken();
	}
	
		
	public static void par() throws Throwable 
	{
		getToken();
		command();
	}

	public static void main(String[] args) throws Throwable
	{
		par();
	}	
}