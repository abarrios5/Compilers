import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
//This is the code for phase 1 
public class LEXER {
	
	static int numVal; // compute the numeric value of a NUMBER token
	static int currChar;// current character
	static TokeType toke;

	static TokeType getNumber(String st) {
		String str = st;
		Pattern p =Pattern.compile("[0-9]+");
		Matcher m = p.matcher(str);
	
		while(m.find()) {
			//System.out.println(m.group());	
			return TokeType.TT_NUMBER;
		}
		return null;//TokeType.TT_NUMBER;
	}

	static TokeType getToken(StringTokenizer str) {
		while(str.hasMoreTokens()) {
			switch (str.nextToken()){
				case "+":  return(TokeType.TT_PLUS); 
				case "*":   return(TokeType.TT_TIMES); 
				case "(":   return(TokeType.TT_LPAREN);			
				case ")":   return(TokeType.TT_RPAREN);
				case "\n":  return(TokeType.TT_EOL);
				case "-":   return(TokeType.TT_SUB);
				case " ": return(TokeType.TT_WSPACE);
				default :   return(TokeType.TT_ERROR); 
			}
		}
		return TokeType.TT_EOL;
	}

	//DriverCODE
	@SuppressWarnings("incomplete-switch")
	public static void main(String[] args) throws Exception {
		TokeType toke, token;
		
		txtReader txt = new txtReader();
		String s = txt.readFileAsString();
		StringTokenizer st = new StringTokenizer(s);
		System.out.println("___________________");
	
		do {
			toke = LEXER.getToken(st);
			token = LEXER.getNumber(s);
			if(token == TokeType.TT_NUMBER) {
				System.out.println("NUMBER");
			}
				switch (toke){
					case TT_WSPACE: System.out.println("TT_WSPACE: ' ' "); break;
					case TT_PLUS : System.out.println("TT_PLUS : +"); break;
					case TT_TIMES:  System.out.println("TT_TIMES : *"); break;
					case TT_LPAREN: System.out.println("TT_LPAREN : ("); break;		
					case TT_RPAREN: System.out.println("TT_RPAREN : )"); break;
					case TT_SUB: System.out.println("TT_SUB : -"); break; 
					case TT_EOL: System.out.println("TT_EOL : " ); break;  
				}
		}while(toke != TokeType.TT_EOL );
	}

}
